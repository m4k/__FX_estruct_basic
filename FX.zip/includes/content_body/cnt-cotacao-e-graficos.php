<div class="container setas">
    <div class="col-xs-12 col-sx-12 col-md-12">
        <a onclick="back()" class="botao fa fa-arrow-left"></a>

        <a onclick="next()" class="botao fa fa-arrow-right"></a>
    </div>
</div>
<div id="cotac-graf">
    <div class="container form1">
        <div class="col-md-8">
            <h5>GRAFICO TÉCNICO</h5>
            <iframe src="https://ssltvc.forexprostools.com/?pair_ID=2103&amp;height=480&amp;width=650&amp;interval=300&amp;plotStyle=candles&amp;domain_ID=30&amp;lang_ID=12&amp;timezone_ID=10" width="100%" height="450px"></iframe>
        </div>
        <div class="col-md-4">
            <h5>RESUMO TÉCNICO</h5>
            <iframe src="https://ssltsw.forexprostools.com?lang=12&amp;forex=2103,1617,1513,1,3,9,10&amp;commodities=8833,8849,8830,8836,8832,8918,8911&amp;indices=166,172,27,167,179,168,170&amp;stocks=358,474,446,334,345,346,347&amp;tabs=1,2,3,4" width="100%" height="450px"></iframe>
        </div>
    </div>

    <div class="container form2 hidden">
        <div class="col-md-12">
            <h5>MOEDAS</h5>
            <iframe src="https://br.investingwidgets.com/live-currency-cross-rates?theme=darkTheme&amp;roundedCorners=true&amp;pairs=1,3,2,4,7,5,8,6,1473,1485,1523,1544,10462,1617,1736,1890,9792,9892,10130,2103,10407" allowtransparency="true" marginwidth="0" marginheight="0" width="100%" height="500px" frameborder="0"></iframe>
        </div>
    </div>

    <div class="container form3 hidden">
        <div class="col-md-12 form3 hidden">
            <h5>COMMODITIES</h5>
            <iframe src="https://br.investingwidgets.com/live-commodities?theme=darkTheme&amp;roundedCorners=true&amp;pairs=8869,8832,8831,8830,8833,8849,8836,8917,8851,49768,13916,8914,8894,8911,8919,8862,8918,961618,8913,8916,8891,8915" allowtransparency="true" marginwidth="0" marginheight="0" width="100%" height="500px" frameborder="0"></iframe>
        </div>
    </div>
</div>