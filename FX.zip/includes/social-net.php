<div>
    <div class="social_net">
        <ul>
            <li><a class="fa fa-facebook" title="facebook" href="#oi2"></a></li>
            <li><a class="fa fa-twitter" title="twitter" href="#oi1"></a></li>            
            <li><a class="fa fa-google-plus" title="google +" href="#oi3"></a></li>
            <li><a class="fa fa-linkedin" title="linkedin" href="#oi5"></a></li>
            <li><a class="fa fa-envelope" title="e-mail" href="#oi4"></a></li>            
        </ul>
    </div>
</div>