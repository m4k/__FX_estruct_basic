<div>
    <div class="logo_site">
        <a href="<?php echo URL_BASE;?>"><img src="./includes/content_head/img/<?php echo LOGO;?>" alt="FX Trader"></a>
    </div>
</div>