<div>
    <div class="container">  
        <div class="transition-loader">
            <div class="transition-loader-inner">
                <label></label>
                <label></label>
                <label></label>
                <label></label>
                <label></label>
                <label></label>
            </div>
        </div>
    </div>
</div>